package com.comphone.appmonitor

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.comphone.appmonitor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appListAdapter: AppListAdapter // המתאם לרשימה
    private val detectedApps = mutableListOf<AppInfo>() // רשימת האפליקציות שזוהו

    // מקלט שידורים לקבלת נתוני אפליקציות מהשירות
    private val appDetectedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == MonitoringService.ACTION_APP_DETECTED) {
                val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getSerializableExtra(MonitoringService.EXTRA_APP_INFO, AppInfo::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getSerializableExtra(MonitoringService.EXTRA_APP_INFO) as? AppInfo
                }
                appInfo?.let {
                    // הוסף את האפליקציה לתחילת הרשימה
                    detectedApps.add(0, it)
                    // שלח את הרשימה המעודכנת למתאם
                    appListAdapter.submitList(detectedApps.toList()) // יצירת עותק כדי ש-DiffUtil יעבוד נכון
                    binding.appsRecyclerView.scrollToPosition(0) // גלול לראש הרשימה
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // אתחול RecyclerView
        appListAdapter = AppListAdapter()
        binding.appsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = appListAdapter
        }

        binding.monitorToggleButton.setOnClickListener {
            toggleMonitoring()
        }

        binding.infoButton.setOnClickListener {
            toggleExplanationVisibility()
        }

        // בדוק את ההרשאות כל פעם שהאפליקציה נפתחת
        checkUsageStatsPermission()
        updateMonitoringButtonState()
    }

    override fun onResume() {
        super.onResume()
        updateMonitoringButtonState()
        checkUsageStatsPermission()

        // רשום את ה-BroadcastReceiver כאשר ה-Activity פעיל
        val filter = IntentFilter(MonitoringService.ACTION_APP_DETECTED)
        LocalBroadcastManager.getInstance(this).registerReceiver(appDetectedReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        // בטל את רישום ה-BroadcastReceiver כאשר ה-Activity לא פעיל
        LocalBroadcastManager.getInstance(this).unregisterReceiver(appDetectedReceiver)
    }


    private fun checkUsageStatsPermission() {
        if (!hasUsageStatsPermission()) {
            binding.monitorToggleButton.isEnabled = false
            showPermissionNeededMessage()
            val intent = Intent(this, PermissionActivity::class.java)
            startActivity(intent)
        } else {
            binding.monitorToggleButton.isEnabled = true
            updateMonitoringButtonState()
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun showPermissionNeededMessage() {
        binding.monitorToggleButton.text = "נדרשת הרשאה!"
    }

    private fun toggleMonitoring() {
        if (isServiceRunning(MonitoringService::class.java)) {
            val serviceIntent = Intent(this, MonitoringService::class.java)
            stopService(serviceIntent)
        } else {
            val serviceIntent = Intent(this, MonitoringService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
        binding.monitorToggleButton.postDelayed({
            updateMonitoringButtonState()
        }, 500)
    }

    private fun updateMonitoringButtonState() {
        val isCurrentlyMonitoring = isServiceRunning(MonitoringService::class.java)

        if (hasUsageStatsPermission()) {
            binding.monitorToggleButton.isEnabled = true
            if (isCurrentlyMonitoring) {
                binding.monitorToggleButton.text = "כיבוי ניטור"
            } else {
                binding.monitorToggleButton.text = "הפעל ניטור"
            }
        } else {
            binding.monitorToggleButton.isEnabled = false
            binding.monitorToggleButton.text = "נדרשת הרשאה!"
        }
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    private fun toggleExplanationVisibility() {
        if (binding.explanationTextView.visibility == View.GONE) {
            binding.explanationTextView.visibility = View.VISIBLE
        } else {
            binding.explanationTextView.visibility = View.GONE
        }
    }
}